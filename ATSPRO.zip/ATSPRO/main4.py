from dataclasses import dataclass
from typing import List, Optional
import requests
from bs4 import BeautifulSoup
import time
import random
from urllib.parse import quote
from requests.adapters import HTTPAdapter
from urllib3.util import Retry
from flask import Flask, request, jsonify

app = Flask(__name__)

@dataclass
class JobData:
    title: str
    company: str
    location: str
    job_link: str
    posted_date: str

class ScraperConfig:
    BASE_URL = "https://www.linkedin.com/jobs-guest/jobs/api/seeMoreJobPostings/search"
    JOBS_PER_PAGE = 25
    MIN_DELAY = 1
    MAX_DELAY = 2
    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

class LinkedInJobsScraper:
    def __init__(self):
        self.session = self._setup_session()

    def _setup_session(self) -> requests.Session:
        session = requests.Session()
        retries = Retry(total=5, backoff_factor=0.5, status_forcelist=[429, 500, 502, 503, 504])
        session.mount("https://", HTTPAdapter(max_retries=retries))
        return session

    def _build_search_url(self, keywords: str, location: str, start: int = 0) -> str:
        params = {
            "keywords": keywords,
            "location": location,
            "start": start,
        }
        return f"{ScraperConfig.BASE_URL}?{'&'.join(f'{k}={quote(str(v))}' for k, v in params.items())}"

    def _clean_job_url(self, url: str) -> str:
        return url.split("?")[0] if "?" in url else url

    def _extract_job_data(self, job_card: BeautifulSoup) -> Optional[JobData]:
        try:
            title = job_card.find("h3", class_="base-search-card__title").text.strip()
            company = job_card.find("h4", class_="base-search-card__subtitle").text.strip()
            location = job_card.find("span", class_="job-search-card__location").text.strip()
            job_link = self._clean_job_url(job_card.find("a", class_="base-card__full-link")["href"])
            posted_date = job_card.find("time", class_="job-search-card__listdate")
            posted_date = posted_date.text.strip() if posted_date else "N/A"
            return JobData(title, company, location, job_link, posted_date)
        except Exception:
            return None

    def _fetch_job_page(self, url: str) -> BeautifulSoup:
        response = self.session.get(url, headers=ScraperConfig.HEADERS)
        response.raise_for_status()
        return BeautifulSoup(response.text, "html.parser")

    def scrape_jobs(self, keywords: str, location: str, max_jobs: int) -> List[JobData]:
        all_jobs = []
        start = 0

        while len(all_jobs) < max_jobs:
            url = self._build_search_url(keywords, location, start)
            soup = self._fetch_job_page(url)
            job_cards = soup.find_all("div", class_="base-card")
            if not job_cards:
                break
            for card in job_cards:
                job_data = self._extract_job_data(card)
                if job_data:
                    all_jobs.append(job_data)
                    if len(all_jobs) >= max_jobs:
                        break
            start += ScraperConfig.JOBS_PER_PAGE
            time.sleep(random.uniform(ScraperConfig.MIN_DELAY, ScraperConfig.MAX_DELAY))
        return all_jobs[:max_jobs]

@app.route("/scrape", methods=["POST"])
def scrape_jobs_endpoint():
    # Accept form fields instead of raw JSON
    keywords = request.form.get("keywords", "AI Engineer")
    location = request.form.get("location", "India")
    limit = int(request.form.get("limit", 10))

    scraper = LinkedInJobsScraper()
    jobs = scraper.scrape_jobs(keywords=keywords, location=location, max_jobs=limit)
    return jsonify([job.__dict__ for job in jobs]), 200

if __name__ == "__main__":
    app.run(debug=True)

from flask import Flask, request, jsonify
import fitz, faiss, random, os
import google.generativeai as genai
from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer

app = Flask(__name__)
genai.configure(api_key="AIzaSyApo3xqLJbuPxkM3_p-dXKj0iQkheKwvBg")

model = genai.GenerativeModel("models/gemini-1.5-pro")
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

strengths = [
    "stakeholder engagement", "planning", "mentoring", "decision-making",
    "analytical thinking", "leadership", "problem-solving", "communication",
    "conflict management", "collaboration", "adaptability", "training abilities"
]

def extract_text_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    return " ".join([page.get_text() for page in doc])

def chunk_resume(text, chunk_size=300, chunk_overlap=50):
    splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    return splitter.split_text(text)

def build_faiss_index(chunks):
    embeddings = embed_model.encode(chunks)
    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(embeddings)
    return index, embeddings, chunks

def search_faiss(query, index, chunks, top_k=3):
    query_vec = embed_model.encode([query])
    D, I = index.search(query_vec, top_k)
    return [chunks[i] for i in I[0]]

def generate_focused_question(strength):
    prompt = (
        f"Generate one specific question about how the candidate demonstrates '{strength}' "
        "in their professional experience. Make it answerable in 3-4 lines maximum."
    )
    response = model.generate_content(prompt)
    return response.text.strip()

def generate_two_answers(question, context):
    prompt = (
        f"Given this resume content:\n\n{context}\n\n"
        f"Provide two distinct 3-4 line answers to this question: '{question}'\n"
        "Format as:\n1. [First answer]\n2. [Second answer]"
    )
    response = model.generate_content(prompt)
    answers = [ans.strip() for ans in response.text.split("\n") if ans.strip()]
    answers = [ans[3:] if ans.startswith(f"{i+1}.") else ans for i, ans in enumerate(answers)]
    return answers[:2]

@app.route("/process_resume", methods=["POST"])
def process_resume():
    if 'file' not in request.files:
        return jsonify({"error": "Missing 'file' in request"}), 400

    file = request.files['file']

    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400

    # Get strengths from form-data (JSON string under key "strengths")
    strengths_data = request.form.get("strengths")
    if not strengths_data:
        return jsonify({"error": "Missing 'strengths' in request"}), 400

    try:
        import json
        strengths_dict = json.loads(strengths_data)
        if not isinstance(strengths_dict, dict):
            raise ValueError("Strengths must be a dictionary.")

        selected_strengths = list(strengths_dict.values())

        temp_path = "temp_" + file.filename
        file.save(temp_path)

        text = extract_text_from_pdf(temp_path)
        chunks = chunk_resume(text)
        index, _, chunk_texts = build_faiss_index(chunks)

        output = {}

        for strength in selected_strengths:
            question = generate_focused_question(strength)
            context_chunks = search_faiss(question, index, chunk_texts)
            context = "\n".join(context_chunks)
            answers = generate_two_answers(question, context)
            output[question] = answers if len(answers) == 2 else ["No answer generated"]

        return jsonify(output)

    except json.JSONDecodeError:
        return jsonify({"error": "Invalid JSON format for 'strengths'"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


if __name__ == "__main__":
    app.run(debug=True)

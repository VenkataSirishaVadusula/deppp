import os
import shutil
import zipfile
import base64
import json
import time
import tempfile
import gc
from flask import Flask, render_template, request, jsonify, send_file, flash, redirect, url_for
from werkzeug.utils import secure_filename
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

# Set default user-agent to avoid environment variable error
os.environ['USER_AGENT'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this to a secure secret key
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Define LLM_MAPPING configuration
LLM_MAPPING = {
    "OpenAI": {
        "model": ["gpt-4", "gpt-4-turbo", "gpt-3.5-turbo", "gpt-4o", "gpt-4o-mini"]
    },
    "Gemini Pro": {
        "model": ["gemini-pro", "gemini-1.5-pro", "gemini-1.5-flash"]
    },
    "Anthropic": {
        "model": ["claude-3-sonnet", "claude-3-haiku", "claude-3-opus"]
    },
    "Ollama": {
        "model": ["llama2", "llama3", "codellama", "mistral"]
    }
}

# Global variables to store session-like data
session_data = {}

def install_playwright():
    """Install playwright only once per session"""
    try:
        print("Installing playwright...")
        result = os.system("playwright install")
        if result == 0:
            print("Playwright installed successfully!")
        else:
            print("Playwright installation failed or already installed")
        return True
    except Exception as e:
        print(f"Error installing playwright: {e}")
        return False

def get_safe_output_directory():
    """Get a safe output directory with proper permissions"""
    possible_dirs = [
        os.path.join(os.getcwd(), "output"),
        os.path.join(os.path.expanduser("~"), "resume_output"),
        os.path.join(tempfile.gettempdir(), "resume_output"),
        tempfile.mkdtemp(prefix="resume_output_")
    ]
    
    for output_dir in possible_dirs:
        try:
            os.makedirs(output_dir, exist_ok=True)
            test_file = os.path.join(output_dir, "test_write.tmp")
            with open(test_file, "w") as f:
                f.write("test")
            os.remove(test_file)
            print(f"Using output directory: {output_dir}")
            return output_dir
        except (PermissionError, OSError) as e:
            print(f"Cannot use directory {output_dir}: {e}")
            continue
    
    fallback_dir = tempfile.mkdtemp(prefix="resume_output_fallback_")
    print(f"Using fallback directory: {fallback_dir}")
    return fallback_dir

def safe_remove_directory(directory_path):
    """Safely remove directory with better error handling"""
    if not os.path.exists(directory_path):
        return True
    
    try:
        gc.collect()
        if os.name == 'nt':
            for root, dirs, files in os.walk(directory_path):
                for file_name in files:
                    file_path = os.path.join(root, file_name)
                    try:
                        os.chmod(file_path, 0o777)
                    except:
                        pass
        
        shutil.rmtree(directory_path)
        print(f"Successfully removed directory: {directory_path}")
        return True
        
    except Exception as e:
        print(f"Error removing directory {directory_path}: {e}")
        return False

def read_file(file_path, mode="r"):
    """Read file content"""
    try:
        with open(file_path, mode) as f:
            return f.read()
    except Exception as e:
        print(f"Error reading file: {e}")
        return None

def overlap_coefficient(text1, text2):
    """Calculate overlap coefficient between two texts"""
    try:
        vectorizer = TfidfVectorizer()
        tfidf_matrix = vectorizer.fit_transform([text1, text2])
        overlap = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
        return overlap
    except Exception as e:
        print(f"Error calculating overlap coefficient: {e}")
        return 0.0

def cosine_similarity_score(text1, text2):
    """Calculate cosine similarity between two texts"""
    try:
        vectorizer = TfidfVectorizer()
        tfidf_matrix = vectorizer.fit_transform([text1, text2])
        similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
        return similarity
    except Exception as e:
        print(f"Error calculating cosine similarity: {e}")
        return 0.0

# Placeholder class - implement based on your actual AutoApplyModel
class AutoApplyModel:
    def __init__(self, api_key, provider, model, downloads_dir):
        self.api_key = api_key
        self.provider = provider
        self.model = model
        self.downloads_dir = downloads_dir
        
    def user_data_extraction(self, file_path, is_st=False):
        return {"name": "Sample User", "skills": ["Python", "ML"], "experience": "5 years"}
    
    def job_details_extraction(self, url=None, job_site_content=None, is_st=False):
        return {"title": "Sample Job", "requirements": ["Python", "ML"]}, "job_details.json"
    
    def resume_builder(self, job_details, user_data, is_st=False):
        return "output/resume.pdf", {"generated": True}
    
    def cover_letter_generator(self, job_details, user_data, is_st=False):
        return "Sample cover letter content", "output/cover_letter.pdf"

def encode_tex_file(file_path):
    try:
        current_loc = os.path.dirname(__file__)
        file_paths = [file_path.replace('.pdf', '.tex'), os.path.join(current_loc, 'zlm', 'templates', 'resume.cls')]
        zip_file_path = file_path.replace('.pdf', '.zip')

        with zipfile.ZipFile(zip_file_path, 'w') as zipf:
            for file_path in file_paths:
                if os.path.exists(file_path):
                    zipf.write(file_path, os.path.basename(file_path))

        with open(zip_file_path, 'rb') as zip_file:
            zip_content = zip_file.read()

        encoded_zip = base64.b64encode(zip_content).decode('utf-8')
        return encoded_zip
    
    except Exception as e:
        print(f"An error occurred while encoding the file: {e}")
        return None

# Initialize on startup
if not hasattr(app, 'playwright_installed'):
    app.playwright_installed = install_playwright()

if not hasattr(app, 'output_directory'):
    app.output_directory = get_safe_output_directory()

@app.route('/')
def index():
    return render_template('index.html', llm_mapping=LLM_MAPPING)

@app.route('/process', methods=['POST'])
def process_resume():
    try:
        # Get form data
        provider = request.form.get('provider')
        model = request.form.get('model')
        api_key = request.form.get('api_key')
        job_url = request.form.get('job_url', '')
        job_text = request.form.get('job_text', '')
        is_url = request.form.get('is_url') == 'true'
        action = request.form.get('action')  # 'resume', 'cover_letter', or 'both'
        
        # Handle file upload
        uploaded_file = request.files.get('file')
        qa_json_file = request.files.get('qa_json_file')  # New option for resume_strength_qa.json
        
        # Validation
        validation_errors = []
        
        if not uploaded_file and not qa_json_file:
            validation_errors.append("Please upload your resume (PDF/JSON) or resume strength QA JSON file")
        
        if not job_url and not job_text:
            validation_errors.append("Please enter a job posting URL or paste the job description")
        
        if not api_key and provider != "Ollama":
            validation_errors.append(f"Please enter your {provider} API key")
        
        if validation_errors:
            return jsonify({
                'success': False,
                'errors': validation_errors
            }), 400
        
        # Process uploaded files
        os.makedirs("uploads", exist_ok=True)
        file_path = None
        
        if uploaded_file:
            filename = secure_filename(uploaded_file.filename)
            file_path = os.path.join("uploads", filename)
            uploaded_file.save(file_path)
        elif qa_json_file:
            filename = secure_filename(qa_json_file.filename)
            file_path = os.path.join("uploads", filename)
            qa_json_file.save(file_path)
        
        # Initialize model
        resume_llm = AutoApplyModel(
            api_key=api_key, 
            provider=provider, 
            model=model, 
            downloads_dir=app.output_directory
        )
        
        # Extract user data
        user_data = resume_llm.user_data_extraction(file_path, is_st=True)
        
        # Clean up uploaded file
        if os.path.exists("uploads"):
            shutil.rmtree("uploads")
        
        if user_data is None:
            return jsonify({
                'success': False,
                'error': 'User data could not be processed. Please upload a valid file'
            }), 400
        
        # Extract job details
        if is_url and job_url:
            job_details, jd_path = resume_llm.job_details_extraction(url=job_url, is_st=True)
        elif job_text:
            job_details, jd_path = resume_llm.job_details_extraction(job_site_content=job_text, is_st=True)
        else:
            return jsonify({
                'success': False,
                'error': 'Please provide job description'
            }), 400
        
        if job_details is None:
            return jsonify({
                'success': False,
                'error': 'Job details could not be processed'
            }), 400
        
        result = {
            'success': True,
            'user_data': user_data,
            'job_details': job_details
        }
        
        # Generate resume if requested
        if action in ['resume', 'both']:
            resume_path, resume_details = resume_llm.resume_builder(job_details, user_data, is_st=True)
            
            # Store file path for download
            session_data['resume_path'] = resume_path
            
            # Calculate metrics
            metrics = {}
            for metric in ['overlap_coefficient', 'cosine_similarity_score']:
                if metric == 'overlap_coefficient':
                    user_personalization = overlap_coefficient(json.dumps(resume_details), json.dumps(user_data))
                    job_alignment = overlap_coefficient(json.dumps(resume_details), json.dumps(job_details))
                    job_match = overlap_coefficient(json.dumps(user_data), json.dumps(job_details))
                else:
                    user_personalization = cosine_similarity_score(json.dumps(resume_details), json.dumps(user_data))
                    job_alignment = cosine_similarity_score(json.dumps(resume_details), json.dumps(job_details))
                    job_match = cosine_similarity_score(json.dumps(user_data), json.dumps(job_details))
                
                metrics[metric] = {
                    'user_personalization': round(user_personalization, 3),
                    'job_alignment': round(job_alignment, 3),
                    'job_match': round(job_match, 3)
                }
            
            # Create Overleaf button data
            tex_content = encode_tex_file(resume_path)
            
            result['resume'] = {
                'path': resume_path,
                'details': resume_details,
                'metrics': metrics,
                'overleaf_content': tex_content
            }
        
        # Generate cover letter if requested
        if action in ['cover_letter', 'both']:
            cv_details, cv_path = resume_llm.cover_letter_generator(job_details, user_data, is_st=True)
            
            # Store file path for download
            session_data['cover_letter_path'] = cv_path
            
            result['cover_letter'] = {
                'path': cv_path,
                'content': cv_details
            }
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'An error occurred: {str(e)}'
        }), 500

@app.route('/download/<file_type>')
def download_file(file_type):
    try:
        if file_type == 'resume':
            file_path = session_data.get('resume_path')
        elif file_type == 'cover_letter':
            file_path = session_data.get('cover_letter_path')
        else:
            return "File not found", 404
        
        if file_path and os.path.exists(file_path):
            return send_file(file_path, as_attachment=True, download_name=os.path.basename(file_path))
        else:
            return "File not found", 404
    except Exception as e:
        return f"Error downloading file: {str(e)}", 500

@app.route('/refresh', methods=['POST'])
def refresh():
    # Clear any cached data
    session_data.clear()
    return jsonify({'success': True, 'message': 'Session refreshed'})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
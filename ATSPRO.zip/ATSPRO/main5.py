from flask import Flask, request, jsonify
import os
import fitz
import faiss
import random
import time
import google.generativeai as genai
from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
from typing import List, Dict

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ========== CONFIG ==========
GEMINI_API_KEY = "AIzaSyApo3xqLJbuPxkM3_p-dXKj0iQkheKwvBg"  # Replace with your actual key
genai.configure(api_key=GEMINI_API_KEY)

model = genai.GenerativeModel("models/gemini-1.5-pro")
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

# ✅ Your fixed strengths list
strengths = [
    "stakeholder engagement", "planning", "mentoring", "decision-making",
    "analytical thinking", "leadership", "problem-solving", "communication",
    "conflict management", "collaboration", "adaptability", "training abilities"
]

# ========== UTIL FUNCTIONS ==========
def extract_text_from_pdf(pdf_path: str) -> str:
    doc = fitz.open(pdf_path)
    return " ".join([page.get_text() for page in doc])

def chunk_resume(text: str, chunk_size=300, chunk_overlap=50) -> List[str]:
    splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    return splitter.split_text(text)

def build_faiss_index(chunks: List[str]):
    embeddings = embed_model.encode(chunks)
    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(embeddings)
    return index, embeddings, chunks

def search_faiss(query: str, index, chunks, top_k=3):
    query_vec = embed_model.encode([query])
    D, I = index.search(query_vec, top_k)
    return [chunks[i] for i in I[0]]

def generate_focused_question(strength: str) -> str:
    prompt = (
        f"Generate one specific interview-style question about how a candidate demonstrates '{strength}' "
        f"in their professional experience. Make it concise and answerable in 3–4 lines."
    )
    response = model.generate_content(prompt)
    time.sleep(1)
    return response.text.strip()

def generate_two_answers(question: str, context: str) -> List[str]:
    context = context[:3000]  # Trim context for Gemini prompt size
    prompt = (
        f"Given this resume content:\n\n{context}\n\n"
        f"Provide two distinct answers (3-4 lines each) to this question: '{question}'\n"
        "Format your response as:\n1. [Answer one]\n2. [Answer two]"
    )
    response = model.generate_content(prompt)
    time.sleep(1)
    raw_lines = [line.strip() for line in response.text.split("\n") if line.strip()]
    answers = []
    for line in raw_lines:
        if line.startswith("1.") or line.startswith("2."):
            answers.append(line[3:].strip())
        elif answers:
            answers[-1] += " " + line.strip()
    return answers[:2]

# ========== MAIN PIPELINE ==========
def process_resume_to_json(pdf_path: str) -> Dict:
    output_json = {}
    text = extract_text_from_pdf(pdf_path)
    chunks = chunk_resume(text)
    index, embeddings, chunk_texts = build_faiss_index(chunks)

    selected_strengths = random.sample(strengths, 5)

    for strength in selected_strengths:
        # Generate a specific question tied to the strength
        prompt = (
            f"Write a behavioral interview question that indirectly evaluates the candidate’s '{strength}' "
            f"without mentioning the word itself. Use STAR-style (situation, task, action, result)."
        )
        response = model.generate_content(prompt)
        time.sleep(1)
        question = response.text.strip()

        # Use FAISS to get contextual resume chunks for this question
        context_chunks = search_faiss(question, index, chunk_texts)
        context = "\n".join(context_chunks)

        # Generate 2 grounded answers
        answers = generate_two_answers(question, context)
        if len(answers) == 2:
            output_json[question] = answers

    return output_json


# ========== FLASK ENDPOINT ==========
@app.route("/upload_resume", methods=["POST"])
def upload_resume():
    try:
        if "file" not in request.files:
            return jsonify({"error": "No file uploaded"}), 400

        file = request.files["file"]
        if not file.filename.endswith(".pdf"):
            return jsonify({"error": "Only PDF files are supported"}), 400

        save_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(save_path)

        result = process_resume_to_json(save_path)
        return jsonify(result), 200

    except Exception as e:
        print("ERROR:", str(e))
        return jsonify({"error": str(e)}), 500

# ========== RUN ==========
if __name__ == "__main__":
    app.run(debug=True)

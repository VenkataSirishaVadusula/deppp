import os
import fitz  # PyMuPDF
import faiss
import random
import google.generativeai as genai
from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
from typing import List, Dict
import json

# ========== 1. CONFIGURATION ==========
GEMINI_API_KEY = "YOUR_GOOGLE_API_KEY"
genai.configure(api_key="AIzaSyApo3xqLJbuPxkM3_p-dXKj0iQkheKwvBg")

model = genai.GenerativeModel("models/gemini-1.5-pro")
embed_model = SentenceTransformer("all-MiniLM-L6-v2")  # fast + lightweight

strengths = [
    "stakeholder engagement", "planning", "mentoring", "decision-making",
    "analytical thinking", "leadership", "problem-solving", "communication",
    "conflict management", "collaboration", "adaptability", "training abilities"
]

# ========== 2. LOAD & SPLIT RESUME ==========
def extract_text_from_pdf(pdf_path: str) -> str:
    doc = fitz.open(pdf_path)
    return " ".join([page.get_text() for page in doc])

def chunk_resume(text: str, chunk_size=300, chunk_overlap=50) -> List[str]:
    splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    return splitter.split_text(text)

# ========== 3. BUILD FAISS VECTOR DB ==========
def build_faiss_index(chunks: List[str]):
    embeddings = embed_model.encode(chunks)
    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(embeddings)
    return index, embeddings, chunks

def search_faiss(query: str, index, chunks, top_k=3):
    query_vec = embed_model.encode([query])
    D, I = index.search(query_vec, top_k)
    return [chunks[i] for i in I[0]]

# ========== 4. LLM: QUESTION & ANSWER GENERATION ==========
def generate_focused_question(strength: str) -> str:
    prompt = (
        f"Generate one specific question about how the candidate demonstrates '{strength}' "
        "in their professional experience. Make it answerable in 3-4 lines maximum. "
        "Example: 'Can you describe a situation where you effectively used {strength} to resolve a challenge?'"
    )
    response = model.generate_content(prompt)
    return response.text.strip()

def generate_two_answers(question: str, context: str) -> List[str]:
    prompt = (
        f"Given this resume content:\n\n{context}\n\n"
        f"Provide two distinct 3-4 line answers to this question: '{question}'\n"
        "Format as:\n1. [First answer]\n2. [Second answer]"
    )
    response = model.generate_content(prompt)
    
    # Parse the response to extract two answers
    answers = [ans.strip() for ans in response.text.split("\n") if ans.strip()]
    answers = [ans[3:] if ans.startswith(f"{i+1}.") else ans for i, ans in enumerate(answers)]
    return answers[:2]  # Ensure we only return exactly 2 answers

# ========== 5. MAIN PIPELINE ==========
def process_resume_to_json(pdf_path: str) -> Dict:
    output_json = {}
    print("🔄 Extracting and embedding resume...")
    text = extract_text_from_pdf(pdf_path)
    chunks = chunk_resume(text)
    index, embeddings, chunk_texts = build_faiss_index(chunks)

    # Select 3 random strengths without replacement
    selected_strengths = random.sample(strengths, 3)
    print(f"Selected strengths: {', '.join(selected_strengths)}")

    for strength in selected_strengths:
        print(f"\n💪 Processing strength: {strength}")
        question = generate_focused_question(strength)
        context_chunks = search_faiss(question, index, chunk_texts)
        context = "\n".join(context_chunks)
        answers = generate_two_answers(question, context)

        # Ensure we have exactly 2 answers
        if len(answers) == 2:
            output_json[question] = answers
        else:
            print(f"Warning: Didn't get 2 answers for {strength}")

    return output_json

# ========== 6. RUN ==========
if __name__ == "__main__":
    resume_path = r"C:\Users\tilla\OneDrive\Documents\ATSPRO\kamalsaitillarigenai6.pdf"  # Replace with your actual file
    result = process_resume_to_json(resume_path)

    with open("resume_strength_qa.json", "w") as f:
        json.dump(result, f, indent=4)

    print("✅ JSON output saved to resume_strength_qa.json")